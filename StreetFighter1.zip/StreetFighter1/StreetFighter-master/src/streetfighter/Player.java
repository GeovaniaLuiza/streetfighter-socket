package streetfighter;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import streetfighterMoves.FighterList;
import streetfighterMoves.Combat;
import streetfighterMoves.Fighter;

/**
 * Player class
 *
 * @author Geovania
 */
public final class Player extends JFrame {

    private final Container contentPane;
    private final JTextArea combatInfo;
    private final JTextArea combatLog;

    private Fighter playerFighter;
    private Fighter enemyFighter;

    private JButton b1;
    private JButton b2;
    private JButton b3;
    private JButton b4;

    private JButton p1;
    private JButton p2;
    private JButton p3;
    private JButton p4;

    private final JLabel playerHealth;
    private final JLabel enemyHealth;
    private JLabel playerImage;
    private JLabel enemyImage;

    private final JPanel sprites;
    private final JPanel buttons;
    private final JPanel buttonsDesc;

    private boolean buttonsEnabled;

    private ClientSideConnection clientSideConnection;

    public Player(int width, int height) throws IOException, URISyntaxException {
        contentPane = this.getContentPane();
        combatLog = new JTextArea();
        combatInfo = new JTextArea();
        playerHealth = new JLabel();
        enemyHealth = new JLabel();
        sprites = new JPanel();
        buttons = new JPanel();
        buttonsDesc = new JPanel();

        configureButtonsStreetFighterPicker();
    }

    public void configureButtonsStreetFighterPicker() throws IOException, URISyntaxException {
        // Cammy
        URI img3 = getClass().getResource("/streetfighter/fighter/6.png").toURI();
        BufferedImage myPicture6 = ImageIO.read(new File((img3)));
        p1 = new JButton(new ImageIcon(myPicture6));
        p1.setMinimumSize(new Dimension(80, 80));
        p1.setName("6");

        // ChunLi
        URI img4 = getClass().getResource("/streetfighter/fighter/9.png").toURI();
        BufferedImage myPicture9 = ImageIO.read(new File((img4)));
        p2 = new JButton(new ImageIcon(myPicture9));
        p2.setMinimumSize(new Dimension(80, 80));
        p2.setName("9");

        // Ryu
        URI img105 = getClass().getResource("/streetfighter/fighter/105.png").toURI();
        BufferedImage myPicture105 = ImageIO.read(new File((img105)));
        p3 = new JButton(new ImageIcon(myPicture105));
        p3.setMinimumSize(new Dimension(80, 80));
        p3.setName("105");

        // Ken
        URI img5 = getClass().getResource("/streetfighter/fighter/282.png").toURI();
        BufferedImage myPicture282 = ImageIO.read(new File((img5)));
        p4 = new JButton(new ImageIcon(myPicture282));
        p4.setMinimumSize(new Dimension(80, 80));
        p4.setName("282");

        // Fighter ID
        setUpFighterChooserButtons();
    }

    public void configureButtons() throws IOException, URISyntaxException {
        // Button setup
        b1 = new JButton(this.playerFighter.getFighterMove(0).getName());
        b2 = new JButton(this.playerFighter.getFighterMove(1).getName());
        b3 = new JButton(this.playerFighter.getFighterMove(2).getName());
        b4 = new JButton(this.playerFighter.getFighterMove(3).getName());
        b1.setToolTipText(setUpButton(0));
        b2.setToolTipText(setUpButton(1));
        b3.setToolTipText(setUpButton(2));
        b4.setToolTipText(setUpButton(3));
        b1.setFont(new Font("Courier New", Font.PLAIN, 18));
        b2.setFont(new Font("Courier New", Font.PLAIN, 18));
        b3.setFont(new Font("Courier New", Font.PLAIN, 18));
        b4.setFont(new Font("Courier New", Font.PLAIN, 18));

        // Button identifiers
        b1.setName("0");
        b2.setName("1");
        b3.setName("2");
        b4.setName("3");

        // Player picture
        URI img = getClass().getResource("/streetfighter/fighter/back/" + playerFighter.getNumber() + ".png").toURI();
        BufferedImage myPicture = ImageIO.read(new File((img)));
        playerImage = new JLabel(new ImageIcon(myPicture));
        playerImage.setMinimumSize(new Dimension(80, 80));

        // Imagem do primeiro oponente (StreetFighter)
        URI img2 = getClass().getResource("/streetfighter/fighter/egg.png").toURI();
        BufferedImage myPicture2 = ImageIO.read(new File((img2)));
        enemyImage = new JLabel(new ImageIcon(myPicture2));
        enemyImage.setMinimumSize(new Dimension(80, 80));

        connectToServer();
        if (clientSideConnection.isAlive()) { //se a conexão com o cliente está estabelecida
            // iniciar interface e botoes
            setUpGUI();
            setUpButtons();
        } else { //apresentar uma janela ocm a mensagem de aviso de que a conexão foi recusada
            JOptionPane.showMessageDialog(null, "Connection refused. Try again soon!");
        }
    }

    public String setUpButton(int id) {
        return ("<html>"
                + "<p style='font-size: 8px'><b>Tipo</b>: "
                + this.playerFighter.getFighterMove(id).getTypeName() + "</p>"
                + "<p style='font-size: 8px'><b>Golpe</b>: "
                + ((this.playerFighter.getFighterMove(id).getPower() == 0) ? "-" : this.playerFighter.getFighterMove(id).getPower()) + "</p>"
                + "<p style='font-size: 8px'><b>Descrição</b>: "
                + this.playerFighter.getFighterMove(id).getDesc() + "</p>"
                + "</html>");
    }

    public void setUpGUI() {
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.PAGE_AXIS));

        contentPane.remove(p1);
        contentPane.remove(p2);
        contentPane.remove(p3);
        contentPane.remove(p4);

        sprites.setLayout(new GridLayout(2, 2));
        sprites.add(playerHealth);
        sprites.add(enemyHealth);
        sprites.add(playerImage);
        sprites.add(enemyImage);
        contentPane.add(sprites);

        // Adiciona mensagens na caixa de mensagens
        combatLog.setText("Opening game...");
        combatLog.setWrapStyleWord(true);
        combatLog.setLineWrap(true);
        combatLog.setEditable(false);

        combatLog.setFont(new Font("Courier New", Font.PLAIN, 12));

        combatInfo.setWrapStyleWord(true);
        combatInfo.setLineWrap(true);
        combatInfo.setEditable(false);

        combatInfo.setFont(new Font("Courier New", Font.PLAIN, 20));
        // Adiciona os botões na tela
        buttons.setLayout(new GridLayout(2, 2));
        buttons.add(b1);
        buttons.add(b2);
        buttons.add(b3);
        buttons.add(b4);
        contentPane.add(buttons);

        contentPane.add(combatLog);
        contentPane.add(combatInfo);

        combatLog.setText("Connected as player #" + clientSideConnection.getPlayerID());
        buttonsEnabled = true;
        toggleButtons();

        this.setVisible(true);
    }

    public void setUpInitialGUI() { //janela e inicio do jogo
        this.setSize(500, 350);
        this.setTitle("Choose your fighter now and Good Look");
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        contentPane.setLayout(new GridLayout(2, 2));

        contentPane.add(p1);
        contentPane.add(p2);
        contentPane.add(p3);
        contentPane.add(p4);
        this.setVisible(true);
    }

    public void setUpFighterChooserButtons() {
        ActionListener actionListener;

        actionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                JButton button = (JButton) event.getSource();
                FighterList fighterGetter = new FighterList();

                Fighter Fighter = fighterGetter.getFighterByID(button.getName());
                setPlayerFighter (Fighter);
                try {
                    configureButtons();
                } catch (IOException | URISyntaxException ex) {
                    Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        };
        p1.addActionListener(actionListener);
        p2.addActionListener(actionListener);
        p3.addActionListener(actionListener);
        p4.addActionListener(actionListener);
    }

    public void setUpButtons() {
        ActionListener actionListener;

        actionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                JButton button = (JButton) event.getSource();

                if (button.isEnabled()) {
                    // Disable buttons
                    buttonsEnabled = false;
                    toggleButtons();

                    // Send which attack was used
                    clientSideConnection.sendButtonNum(Integer.parseInt(button.getName()));
                    ///cria a Thread
                    Thread t = new Thread(new Runnable() { //implementação de um executável feito na criação da Thread
                        @Override
                        public void run() { //metodo da interface Runnable, que é o run
                            try {
                                updateTurn();
                            } catch (ClassNotFoundException | IOException | URISyntaxException ex) {
                                Logger.getLogger(Player.class.getName()).log(Level.SEVERE, null, ex);
                                //permite que se tenha uma instância de um criador de logs e registre 
                                //uma mensagem com o nível especificado(Severa), contendo o rastreamento de pilha da exceção 
                            }
                        }
                    });
                    t.start(); //chama e inicia a Thread
                }
            }
        };

        b1.addActionListener(actionListener);
        b2.addActionListener(actionListener);
        b3.addActionListener(actionListener);
        b4.addActionListener(actionListener);

    }

    public void toggleButtons() {
        b1.setEnabled(buttonsEnabled);
        b2.setEnabled(buttonsEnabled);
        b3.setEnabled(buttonsEnabled);
        b4.setEnabled(buttonsEnabled);
    }

    public void updateTurn() throws ClassNotFoundException, IOException, URISyntaxException {
        Combat combat = clientSideConnection.receiveCombat();
        setPlayerFighter((this.clientSideConnection.getPlayerID() == 1) ? combat.getPlayer1() : combat.getPlayer2());
        setEnemyFighter((this.clientSideConnection.getPlayerID() == 1) ? combat.getPlayer2() : combat.getPlayer1());

        // Update enemy player picture
        URI img = getClass().getResource("/streetfighter/fighter/" + getEnemyFighter().getNumber() + ".png").toURI();
        BufferedImage enemyImageLocal = ImageIO.read(new File((img)));
        this.enemyImage.setIcon(new ImageIcon(enemyImageLocal));

        combatLog.setText(combat.getFirstMessage());
        if (combat.getSecondMessage() != null) {
            combatLog.setText(combatLog.getText() + "\n" + combat.getSecondMessage());
        }

        playerHealth.setHorizontalAlignment(JLabel.CENTER);
        enemyHealth.setHorizontalAlignment(JLabel.CENTER);
        playerHealth.setText("<html><p style='text-align: center; font-size: 20pt'>" + getPlayerFighter().getName() + "<br>[" + Math.round(getPlayerFighter().getHealthValue())
                + "/" + Math.round(getPlayerFighter().getMaxHealthValue()) + "]</p></html>");
        enemyHealth.setText("<html><p style='text-align: center; font-size: 20pt'>" + getEnemyFighter().getName() + "<br>[" + Math.round(getEnemyFighter().getHealthValue())
                + "/" + Math.round(getEnemyFighter().getMaxHealthValue()) + "]</p></html>");

        if (combat.getWinnerID() != 0) {
            if (combat.getWinnerID() == clientSideConnection.getPlayerID()) {
                combatLog.setText(combatLog.getText()
                        + "\nVocê derrotou " + getEnemyFighter().getName() + "!");
            } else {
                combatLog.setText(combatLog.getText()
                        + "\nVocê foi derrotado por " + getEnemyFighter().getName() + "!");
            }
        } else {
            buttonsEnabled = true;
            toggleButtons();
        }
    }

    public boolean connectToServer() {
        clientSideConnection = new ClientSideConnection(this.playerFighter);

        return (clientSideConnection != null);
    }

    public static void main(String[] args) throws IOException, URISyntaxException, UnsupportedLookAndFeelException {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
        }
        Player p = new Player(500, 100);
        p.setUpInitialGUI();
    }

    public Fighter getPlayerFighter() {
        return playerFighter;
    }

    public void setPlayerFighter(Fighter playerFighter) {
        this.playerFighter = playerFighter;
    }

    public Fighter getEnemyFighter() {
        return enemyFighter;
    }

    public void setEnemyFighter(Fighter enemyFighter) {
        this.enemyFighter = enemyFighter;
    }

}
