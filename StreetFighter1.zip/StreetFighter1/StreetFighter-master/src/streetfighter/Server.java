package streetfighter;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import streetfighterMoves.Combat;
import streetfighterMoves.Fighter;

/**
 * Server class
 *
 * @author Geovania
 */
public class Server {

    private ServerSocket serverSocket;
    private int numPlayers;
    private ServerSideConnection player1;
    private ServerSideConnection player2;

    private int p1ButtonNum;
    private int p2ButtonNum;

    private Combat combat;
    
    private Fighter p2Fighter;
    private Fighter p1Fighter;

    public Server() { 
        System.out.println("Server online!"); //Mensagem de aviso de inicio de conexao do servidor
        numPlayers = 0; //variavel numjogadores inicia com 0

        combat = new Combat(); 

        try { //o bloco inicia a espera da conexao 
            serverSocket = new ServerSocket(20000); //cria o o serverSocker e espera conexao na port 20000
        } catch (IOException ex) {
            System.out.println(ex); //trata exceção caso ocorra algum erro durante a execucao do bloco
        }
    }

    public void acceptConnections() { // inicia o metodo aceitaConexoes
        try {
            System.out.println("Awaiting connections.. "); //apenas um print para verificacao de passagem
            while (numPlayers <= 1) { //laco para o numero de jogadores > 1
                 System.out.println("123");
                Socket socket = serverSocket.accept(); //objeto socket que trata a conexao quando ela for aceita
                numPlayers++; 
                System.out.println("Player number " + numPlayers + " has connected!");
                ServerSideConnection serverSideConnection = new ServerSideConnection(socket, numPlayers);
                if (numPlayers == 1) { //verifica o numero de jogadores
                    player1 = serverSideConnection;
                } else {
                    player2 = serverSideConnection;
                }
                Thread thread = new Thread(serverSideConnection);
                thread.start();  //inicia a thread 
            }
            System.out.println("Reached player limit"); //mensagem de que o numero de jogadores está no maximo
        } catch (IOException ex) { 
            System.out.println(ex);
        }
    }

    private class ServerSideConnection implements Runnable { //classe serverside implementa a interface Runnable

        private Socket socket;
        private ObjectInputStream dataIn;
        private ObjectOutputStream dataOut;
        private int playerID;

        public ServerSideConnection(Socket socketParameter, int id) {
            this.socket = socketParameter;
            this.playerID = id;
            try {
                dataOut = new ObjectOutputStream(socket.getOutputStream());//Escreve no Stream
                dataOut.flush(); //Força que os dados sejam escritos no disco e não fiqueim perdidos em algum lugar da memória
                dataIn = new ObjectInputStream(socket.getInputStream()); //faz a leitura do Stream
            } catch (IOException ex) {
                System.out.println(ex);
            }
        }

        @Override
        public void run() { //método que a thread vai executar
            try {
                dataOut.writeInt(playerID);
                dataOut.flush();

                if (playerID == 1) {
                    setP1Fighter((Fighter) dataIn.readObject());
                    combat.setPlayer1(getP1Fighter());
                } else {
                    setP2Fighter((Fighter) dataIn.readObject());
                    combat.setPlayer2(getP2Fighter());
                }

                p1ButtonNum = p2ButtonNum = -1;
                boolean cont = true;
                while (cont) {
                    System.out.println("123");
                    if (getP1Fighter() != null && getP2Fighter() != null && combat.isReady()) {
                        if (playerID == 1) {
                            p1ButtonNum = dataIn.readInt();
                        } else {
                            p2ButtonNum = dataIn.readInt();
                        }

                        if (p1ButtonNum != -1 && p2ButtonNum != -1) {
                            combat.calculateDamage(p1ButtonNum, p2ButtonNum);
                            p1ButtonNum = p2ButtonNum = -1;

                            setP1Fighter(combat.getPlayer1());
                            setP2Fighter(combat.getPlayer2());

                            player1.sendCombat(combat);
                            player2.sendCombat(combat);

                            if (combat.getWinnerID() != 0) {
                                cont = false;
                            }
                        }
                    }
                }
            } catch (IOException ex) {
                System.out.println(ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        public void sendFighter(Fighter n) {
            try {
                dataOut.writeObject(n);
                dataOut.reset();
            } catch (IOException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        public void sendCombat(Combat n) {
            try {
                dataOut.writeObject(n); //escreve o objeto
                dataOut.reset(); //reseta o stream
            } catch (IOException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }
    
    public static void main(String[] args) { //metodo principal do Java
        Server gs = new Server(); 
        gs.acceptConnections();
    }
 
    public Fighter getP1Fighter() { //retorns o atributo lutador
        return p1Fighter;
    }

    public void setP1Fighter(Fighter p1Fighter) { //não retorna nada
// o métoo recebe o valor passado por parametro
        this.p1Fighter = p1Fighter;
    }

    public Fighter getP2Fighter() {
        return p2Fighter;
    }

    public void setP2Fighter(Fighter p2Fighter) {
        this.p2Fighter = p2Fighter;
    }

}
