package streetfighterMoves;

/**
 * 
 * @author Geovania
 */
public class FighterList extends Fighter {
    public Fighter getFighterByID(String v) {
        switch (v) {
            case "6": 
                return getChunLi();
            case "9":
                return getRuy();
            case "105":
                return getKen();
            case "282":
                return getBlanka();
            default:
                return getCammy();
        }
    }
    
    public Fighter getCammy() {
        Moves[] movesArray = new Moves[4];
        movesArray[0] = new MoveList().getNormalMove(1);
        movesArray[1] = new MoveList().getNormalMove(2);
        movesArray[2] = new MoveList().getWaterMove(1);
        movesArray[3] = new MoveList().getWaterMove(2);
     
        Fighter Cammy = new Fighter();
        Cammy.setNumber(7);
        Cammy.setName("Cammy");
        Cammy.setMoves(movesArray);
        Cammy.setLevel(50);
        Cammy.setPrimaryType(2);
        Cammy.calculateStats();
        return Cammy;
    }
    
    public Fighter getChunLi() {
        Moves[] movesArray = new Moves[4];
        movesArray[0] = new MoveList().getNormalMove(4);
        movesArray[1] = new MoveList().getFireMove(1);
        movesArray[2] = new MoveList().getFlyingMove(1);
        movesArray[3] = new MoveList().getNormalMove(3);
     
        Fighter ChunLi = new Fighter();
        ChunLi.setNumber(6);
        ChunLi.setName("ChunLi");
        ChunLi.setMoves(movesArray);
        ChunLi.setLevel(50);
        ChunLi.setPrimaryType(3);
        ChunLi.setSecondaryType(5);
        
        ChunLi.setHealthStat(78);
        ChunLi.setAttackStat(84, 1);
        ChunLi.setAttackStat(109, 2);
        ChunLi.setDefenseStat(78, 1);
        ChunLi.setDefenseStat(85, 2);
        ChunLi.setSpeedStat(100);
        ChunLi.calculateStats();
        return ChunLi;
    }
    
    public Fighter getBlanka() {
        Moves[] movesArray = new Moves[4];
        movesArray[0] = new MoveList().getWaterMove(3);
        movesArray[1] = new MoveList().getWaterMove(4);
        movesArray[2] = new MoveList().getNormalMove(5);
        movesArray[3] = new MoveList().getSteelMove(1);
     
        Fighter Blanka = new Fighter();
        Blanka.setNumber(9);
        Blanka.setName("Blanka");
        Blanka.setMoves(movesArray);
        Blanka.setLevel(50);
        Blanka.setPrimaryType(2);
        
        Blanka.setHealthStat(79);
        Blanka.setSpeedStat(85);
        Blanka.setAttackStat(83, 1);
        Blanka.setAttackStat(100, 2);
        Blanka.setDefenseStat(105, 1);
        Blanka.setDefenseStat(78, 2);
        
        Blanka.calculateStats();
        return Blanka;
    }
    
    public Fighter getRuy() {
        Moves[] movesArray = new Moves[4];
        movesArray[0] = new MoveList().getFairyMove(1);
        movesArray[1] = new MoveList().getFairyMove(2);
        movesArray[2] = new MoveList().getPsychicMove(1);
        movesArray[3] = new MoveList().getPsychicMove(2);
     
        Fighter Fighter = new Fighter();
        Fighter.setNumber(282);
        Fighter.setName("Ryu");
        Fighter.setMoves(movesArray);
        Fighter.setLevel(50);
        Fighter.setPrimaryType(6);
        
        Fighter.setHealthStat(68);
        Fighter.setAttackStat(65, 1);
        Fighter.setDefenseStat(65, 1);
        Fighter.setAttackStat(125, 2);
        Fighter.setDefenseStat(115, 2);
        Fighter.setSpeedStat(80);
        
        Fighter.calculateStats();
        return Fighter;
    }
    
    public Fighter getKen() {
        Moves[] movesArray = new Moves[4];
        movesArray[0] = new MoveList().getGroundMove(1);
        movesArray[1] = new MoveList().getGroundMove(2);
        movesArray[2] = new MoveList().getNormalMove(2);
        movesArray[3] = new MoveList().getNormalMove(5);
     
        Fighter Fighter = new Fighter();
        Fighter.setNumber(105);
        Fighter.setName("Ken");
        Fighter.setMoves(movesArray);
        Fighter.setLevel(50);
        Fighter.setPrimaryType(6);
        
        Fighter.setHealthStat(60);
        Fighter.setAttackStat(80, 1);
        Fighter.setDefenseStat(110, 1);
        Fighter.setAttackStat(50, 2);
        Fighter.setDefenseStat(80, 2);
        Fighter.setSpeedStat(45);
        
        Fighter.calculateStats();
        return Fighter;
    }
}
